# Professor Bingo 🎓

A customizable bingo card filled with phrases every lecturer says. Tick squares as you hear them, and the app celebrates when you complete a row, column or diagonal.

**Stack:** one self-contained `index.html` (HTML + CSS + vanilla JS). No build step, no backend, no API keys, no `.env`, no login. It uses sample phrases only.

## Theme: Moonlit Lecture Demon Hunt
The game uses an original anime-style night scene: a full moon, hanging wisteria, pagodas, a torii gate, gold swirl clouds, falling sakura petals and fireflies. The cells have glowing gold frames, the side panels look like parchment scrolls, and the stats sit in gold tabs. Every professor cliché is a "demon" to slay:
- **Water on every click:** each button and square makes a splash ripple, rings, droplets and a swirl, with a small water sound.
- Ticking a square adds a blade slash and a red 討 seal.
- **Fire on BINGO:** flames rise across the bottom of the screen and from the winning squares, the modal edges keep burning, the BINGO! text flickers, and a whoosh and drum sound plays.
- **Victory panel:** shows the line(s), an XP ribbon, a rank-up notice and an achievement checklist (1 line, 2+ lines, diagonal, 4 corners, full house).
- **Win target setting:** choose whether BINGO needs 1, 2 or 3 lines.
- **XP and ranks:** +10 XP per tick, combo bonuses for quick ticks, and +100 XP per line. Ranks go from Ink Novice to Legend of the Lecture Hall.
- **Quiet Classroom Mode** works as a stealth mode: it turns off all sound, particles, shake and pop-ups, greys out the moon, and shows wins as a small toast.

All visuals are CSS, SVG and canvas, and all sounds are generated in the browser with WebAudio. The only external file is Google Fonts; if it fails to load, the page falls back to system fonts.

## Run it
Open `index.html` in any browser (keep the `css/` and `js/` folders next to it), or deploy the folder to any static host (Render static site, Netlify, GitHub Pages).

## Judge verification path
1. **Tick squares until a line is complete.** Example: tap all 5 squares in the top row.
2. **Win state.** A "BINGO!" modal names the completed line, lists its phrases, plays a chime and shows confetti. The winning cells stay highlighted in gold.
3. **Quiet Classroom Mode → fresh card.** Turn on the toggle at the top right, then press **Generate fresh card**. Quiet mode turns off sound, confetti and pop-ups, mutes the colours, and shows wins as a small toast in the corner.

## MVP requirements
| Requirement | Where |
|---|---|
| Bingo grid with relatable lecture phrases | 5×5 grid with a FREE centre, drawn from a 28–30 phrase deck |
| Tick and untick squares | Tap or click, or use Space/Enter. Undo is also available |
| Detect row, column or diagonal and show a result | All 12 lines are checked after every tick. Unticking removes the win |

## Validation
- The custom phrase editor trims and de-duplicates entries (ignoring case) and rejects lines longer than 60 characters.
- A card needs at least 24 unique phrases (25 without the free space). Until then, **Apply** stays disabled and an error message explains what is missing.
- The FREE square can't be unticked.

## Extra features
- **Three phrase decks:** Any lecture, Online class and CS / Engineering, plus fully custom phrases.
- **Lecture log:** records when each phrase was said ("Phones away — 10:42 AM").
- **Scoreboard:** lines now, total bingos and cards played. Several lines at once and a full-card **blackout** are detected.
- **Undo** for the last tick and **Clear ticks** to reset the card.
- **Accessibility:** arrow-key navigation, `aria-pressed` squares and live announcements. Animations are skipped when the system requests reduced motion.
- **Keyboard shortcuts:** `N` new card · `Q` quiet mode · `Z` undo.
- **Saved progress:** the browser's localStorage keeps your card through a refresh. Nothing leaves the device.

## Build rules compliance
Browser-only ✔ · No external API, paid service, login or database ✔ · No `.env` ✔ · Fictional, generic data only ✔ · The main user journey works end-to-end with validation and a visible result ✔
