> Paste only the text inside the code block into Antigravity. Wait until it finishes and check the result in the browser before the next phase.

# PHASE 5 — Characters in the modal + final test (5 min)

```text
1. In the BINGO modal slots #modalLeft and #modalRight, show Kai (fist raised, happy closed eyes) and Yuki (hands clasped, smiling) using a second small Three.js renderer with a gentle bounce loop. Only render while the modal is open. If it isn't possible quickly, draw the stage canvases into the slots with drawImage each frame instead.
2. Full test, then fix all console errors:
   - Play as guest → tick 5 in a row → water on every click, fire + characters' victory + BINGO modal with checklist.
   - View Scoreboard → my row highlighted and updated.
   - Quiet mode ON → no sound, but button clicks still show water animations; Generate fresh card works.
   - Custom phrases with fewer than 24 entries shows a validation error.
   - Mobile width 390px: the layout stacks, characters are hidden, and everything is usable.
3. Update README.md: add the sections "3D Characters (original, built with Three.js primitives)", "Hunter Login & Scoreboard (local only, fictional data)" and "Quiet Mode behaviour". Save screenshots to docs/screenshots/.
```

---
**Done.** Record your proof video (judge path + scoreboard).
