> Paste only the text inside the code block into Antigravity. Wait until it finishes and check the result in the browser before the next phase.

# PHASE 4 — Hunter login + scoreboard page (9 min)

```text
Add a LOCAL-ONLY "Hunter Login" and a "Scoreboard" view. No real authentication, no server, no passwords. Data is stored only in localStorage (wrapped in try/catch), and the preloaded leaderboard entries are fictional.

1. LOGIN SCREEN (replace the current intro overlay, same moonlit style):
   - Title "ENTER THE HUNT", a parchment card with:
     - "Hunter name" text input (validation: required, 2–16 chars, letters/numbers/spaces only, show an inline red error message)
     - Avatar picker: 4 original emblem icons (wave, flame, moon, sakura) drawn as SVG
     - Red button "Begin the hunt" (disabled until valid) and a dark text button "Play as guest" (name = "Guest Hunter").
   - The judge must be able to click "Play as guest" and play immediately.
   - Show the logged-in hunter name + emblem in the title bar with a small "Switch hunter" link that reopens this screen.

2. SCOREBOARD PAGE (a full-screen overlay opened by a new gold tab "SCOREBOARD" next to the stat tabs, and by a "View Scoreboard" button in the BINGO modal):
   - Styled like a large parchment scroll with a gold title "HALL OF HUNTERS".
   - Table columns: Rank · Emblem · Hunter · Rank title · XP · Bingos · Best combo.
   - Pre-fill 7 FICTIONAL sample hunters (e.g. "Moonblade Riku", "Ember Sana", "Quiet Kenji", "Lantern Mei", "Ink Daichi", "Petal Aiko", "Storm Haru") with sample stats.
   - The current player's row is highlighted with a glowing gold border and updates live after every tick/bingo (XP, bingos, best combo). Sort by XP.
   - Tabs: "All time" / "This session". A "Reset my score" button with an in-page confirm dialog (no browser alert()).
   - Top 3 rows get gold/silver/bronze medal badges; rows slide in with a staggered animation (still plays in quiet mode, without sound).
   - Close button returns to the game.
3. Track bestCombo in the state.
Keep the judge path working: Play as guest → tick a line → BINGO → quiet mode → fresh card.
```

---
**Next:** open `phase-05-modal-characters-final-test.md`
