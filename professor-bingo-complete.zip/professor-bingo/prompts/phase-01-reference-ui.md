> Paste only the text inside the code block into Antigravity. Wait until it finishes and check the result in the browser before the next phase.

# PHASE 1 — Exact reference UI layout (8 min)

```text
Restyle the layout to match this reference exactly (keep all existing logic and IDs):

SCENE (already exists, refine it): purple-indigo night sky, a large pale-gold full moon at the top-left, hanging purple wisteria in both top corners swaying gently, pagoda silhouettes with glowing orange lanterns, a red torii gate at the bottom-right, golden swirl clouds at the bottom-left and bottom-right, and falling sakura petals.

DESKTOP LAYOUT (>=1280px), 3 columns:
- LEFT column (300px): "character stage", an empty container with id="stageLeft" (used in Phase 2).
- CENTER: the 5x5 bingo board. Cells are dark crimson-black with a thin gold double border, rounded 7px, white bold condensed text, and a small red sakura icon in the bottom-right corner. Ticked cells get a bright gold glowing border, a small red square stamp icon at the top-left, and a diagonal light slash. The CENTER cell is solid red with large gold "無料" and "FREE" under it. Below the board, one row of buttons: a red "Generate fresh card" button with a gold flower icon, "Undo" and "Clear ticks" (dark with gold border). Below that, a thin footer bar: "Running entirely in your browser with sample phrases — no login server, nothing leaves this page."
- RIGHT column (350px): at the top, 3 gold-framed dark tabs in a row (LINES NOW / BINGOS / CARDS) with gold numbers. Below them, a parchment SCROLL panel (beige paper with rolled wooden ends at top and bottom) titled "CUSTOMIZE CARD" with a red flower icon, containing: "DEMON DECK" dropdown (dark), "PHRASES — ONE PER LINE" dark textarea, radio buttons "1 line / 2 lines / 3 lines", checkbox "Free space in the center", a red "Apply & save card" button and a dark "Reset deck" button. Below it, a second parchment scroll titled "HUNT LOG" with a list: flower icon, text, time on the right.
- Add a small gold-framed badge at the bottom-right: "Moonlit Hunt Theme".
- Keep the title bar (PROFESSOR BINGO, rank/XP bar, Quiet Classroom Mode switch) above the board.

BINGO MODAL (restyle the existing #overlay):
- 720px wide, dark red panel with a double gold border, gold flower ornaments in the corners, and gold swirl clouds peeking out at the bottom corners.
- Empty slots on the left and right side of the modal, 170px wide each, with id="modalLeft" and id="modalRight" (for characters in Phase 4).
- Center: a huge "BINGO!" in a brush script font with a fire gradient (yellow→orange→red) and a flickering glow; under it "⟡━ BINGO 2 COMPLETE ━⟡" in gold caps; a gold ribbon pill "+2 LINES"; red-orange text "A LEGENDARY TEACHER MOMENT!"; a checklist with gold checkboxes (2 lines in a row, 1 line in any direction, corner line (diagonal), 4 corners, full house); and buttons "Play Again" (dark) + "New Card" (red).

RESPONSIVE: below 1280px hide the character stages; below 940px stack the right column under the board.
Test the judge path afterwards and fix anything broken.
```

---
**Next:** open `phase-02-3d-characters.md`
