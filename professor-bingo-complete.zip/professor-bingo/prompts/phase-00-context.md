> Paste only the text inside the code block into Antigravity. Wait until it finishes and check the result in the browser before the next phase.

# PHASE 0 — Context (2 min)

```text
Read ANTIGRAVITY.md, README.md, index.html, css/style.css and js/app.js before changing anything.
This is a WORKING hackathon project ("Professor Bingo — Lecture Demon Hunt"). Rules you must keep for every phase:
1. Browser-only: no backend, no external API, no real login provider, no database, no secret keys, no .env. Only Three.js and Google Fonts may load from a CDN.
2. Fictional/sample data only.
3. The judge path must always work: (a) tick squares until a row/column/diagonal completes, (b) the win state appears, (c) turn on Quiet Classroom Mode and click "Generate fresh card".
4. All characters and art must be ORIGINAL. Do not recreate, name or resemble any existing anime/manga character, logo or franchise.
5. Use the 3D animation skills already installed in this workspace for all 3D work.
Reply only with a short summary of the file structure and the main functions in js/app.js. Do not edit files yet.
```

---
**Next:** open `phase-01-reference-ui.md`
