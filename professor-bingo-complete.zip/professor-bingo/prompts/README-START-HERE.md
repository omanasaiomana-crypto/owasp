# Professor Bingo — Antigravity Build Plan (45 minutes)

> **How to use:** Unzip `professor-bingo.zip`, open the `professor-bingo` folder in Antigravity, and paste **one phase at a time** in order. Wait for each phase to finish and check it in the browser before moving on.
> **Back up the zip first.** If a phase breaks something, restore it and skip that phase.
> **Time plan:** P0 2 min · P1 8 min · P2 12 min · P3 6 min · P4 9 min · P5 5 min · buffer 3 min = **45 min**


## Phase files (in order)
0. `phase-00-context.md`
1. `phase-01-reference-ui.md`
2. `phase-02-3d-characters.md`
3. `phase-03-connect-quiet-mode.md`
4. `phase-04-login-scoreboard.md`
5. `phase-05-modal-characters-final-test.md`

## If you're short on time
- **Running late after Phase 2?** Skip Phase 5, step 1 (characters in the modal). The stage characters already make the demo.
- **Phase 2 fails?** Restore the zip and go straight to Phase 4. The login and scoreboard still add value.
- **Record the proof video** (judge path + scoreboard) as soon as Phase 4 works.
