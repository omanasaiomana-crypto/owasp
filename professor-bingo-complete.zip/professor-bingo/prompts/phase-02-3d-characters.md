> Paste only the text inside the code block into Antigravity. Wait until it finishes and check the result in the browser before the next phase.

# PHASE 2 — Original animated 3D characters (12 min)

```text
Using the installed 3D skills, add Three.js (r160+ from cdnjs or jsdelivr) and create js/characters3d.js.

Build TWO ORIGINAL stylized chibi anime characters from Three.js primitives only (no downloaded models), with MeshToonMaterial, black outline (inverted-hull or OutlineEffect), and warm moon rim lighting. Render each in its own transparent canvas inside #stageLeft and #stageRight (add #stageRight as the right-side stage if missing, or overlay it at the bottom-right of the right column on narrow screens).

1. "KAI — the Lecture Hunter" (left): an original young swordsman: spiky dark-navy hair, white headband, deep-blue haori with gold wave trim over a black uniform, a katana whose blade glows cyan-blue. Holding a water-style stance.
2. "YUKI — the Lantern Spirit" (right): an original fox-spirit girl: long white hair, small fox ears, a crimson-and-white kimono with a gold obi, holding a glowing paper lantern.
Both must be clearly original and must NOT resemble any existing anime character.

ANIMATIONS (small tween system using requestAnimationFrame + easing):
- idle (always loops): breathing scale, head tilt, hair and sleeve sway, blinking eyes, floating petals around them.
- kai.slash(): a fast diagonal sword swing with a cyan blade trail (TubeGeometry or a fading ribbon mesh), then return to idle.
- yuki.cheer(): a small hop with the lantern swinging and the lantern glow pulsing.
- victory(): both jump; Kai raises his sword overhead with a flame-colored glow, Yuki claps; lasts 2.5s.
- click(): a small reaction (Kai nods / Yuki ear twitch) for any button click.

Export window.chars = { slash(), cheer(), victory(), click(), setQuiet(on) }.
Performance: cap pixelRatio at 1.5, pause when document.hidden, ~60fps.
Fallback: if WebGL or Three.js is unavailable, hide the stages and the game keeps working.
```

---
**Next:** open `phase-03-connect-quiet-mode.md`
