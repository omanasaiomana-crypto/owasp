> Paste only the text inside the code block into Antigravity. Wait until it finishes and check the result in the browser before the next phase.

# PHASE 3 — Connect characters + Quiet Mode animation rules (6 min)

```text
Wire the characters into js/app.js using optional chaining (window.chars?.x()) so nothing can crash:
- When a square becomes ticked: chars.slash() + chars.cheer(), and spawn the existing water() effect along an arc from Kai's stage to the ticked cell (a "water blade" travelling to the square).
- On BINGO in celebrate(): chars.victory() at the same moment the fire starts.
- On EVERY button click (all .btn, .cell, .switch): chars.click().

NEW QUIET CLASSROOM MODE RULES (change the current behaviour):
- Quiet mode = SILENT. All sounds are muted.
- Visual click animations STILL play in quiet mode: the water ripple inside buttons/cells, a small water splash, and the characters' click()/slash()/cheer() reactions, at about 50% intensity (fewer particles, smaller rings).
- On BINGO in quiet mode: show a SMALL fire effect only around the winning squares (no full-screen fire, no flash) plus the existing corner toast; the characters do a small victory nod instead of the jump.
- Ambient petals and fireflies keep running but at half the count.
- chars.setQuiet(on) lowers the characters' animation amplitude by half.
Update the toast text when toggling: "Quiet Classroom Mode on — silent, subtle animations".
Test: with quiet mode ON, clicking any button must still show the water animation with no sound.
```

---
**Next:** open `phase-04-login-scoreboard.md`
